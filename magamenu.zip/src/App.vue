<template>
  <div id="app">
    <freelancer_navbar />
    <freelancer_header source=header />
    <freelancer_portfolio source=portfolio @update-cart="updateCart" @upd="upd"/>
    <freelancer_about data=about />
    <freelancer_portfolio source=portfolio2 />
    <freelancer_about data=about2 />
    <freelancer_contact data=contact />
    <freelancer_footer data=footer />
    
    
    <div class="fixed-bottom">
        <!-- <freelancer_copyright source=copyright /> -->
        <!-- Copyright Section-->
      <section  class="copyright py-4 text-center text-white">
          <div>
              <b-button v-b-modal.modal-lg  variant="primary">Continuar</b-button>
              <b-modal id="modal-lg" centered size="lg" title="Pedido">
                   <rad_logo 
                data="logo" 
                view="vertical"
                img_size = "50px"
                title_style = "color: black; font-size: 20px; font-family: 'Varela Round', Helvetica, Arial, sans-serif;"
                subtitle_hidden = true
                subtitle_size = "17px"
                desc_size = "11px"/><br>
                  <table class="table">
                    <thead>
                      <tr>
                        <th scope="col">#</th>
                        <th scope="col">Produto</th>
                        <th scope="col">Valor</th>
                        <th scope="col">Qtd.</th>
                        <!-- <th scope="col">Sub-total</th> -->
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(item, index) in sortedCart" :key="index">
                        <th scope="row">{{index + 1}}</th>
                        <td>{{item.title}}</td>
                        <td>{{item.price}}</td>
                        <td>{{item.qnt}}</td>
                        <!-- <td>{{parseInt(item.qnt) * parseInt(item.price)}}</td> -->
                      </tr>
                       <tr>
                        <th scope="row"></th>
                        <td></td>
                        <!-- <td></td> -->
                        <td align=right>Total:</td>
                        <td>{{total}}</td>
                      </tr>
                    </tbody>
                  </table>
              </b-modal>
          </div>
          <!-- <div class="container"><small>Copyright © <a :href='data.link'>{{data.title}}</a></small></div> -->
      </section>
    </div>
  </div>
</template>
<style scoped>
  table {
    font-size: 12px;
  }
</style>

<script>
  import freelancer_navbar from './components/freelancer_navbar.vue'
  import freelancer_header from './components/freelancer_header.vue'
  import freelancer_portfolio from './components/freelancer_portfolio.vue'
  import freelancer_about from './components/freelancer_about.vue'
  import freelancer_contact from './components/freelancer_contact.vue'
  import freelancer_footer from './components/freelancer_footer.vue'
  // import freelancer_copyright from './components/freelancer_copyright.vue'
  import rad_logo from './components/rad_logo.vue'
  export default {
    name: 'App',
    data() {
      return {
        cart: []
      }
    },
    components: {
      rad_logo,
      freelancer_navbar, 
      freelancer_header, 
      freelancer_portfolio, 
      freelancer_about, 
      freelancer_contact,
      freelancer_footer
      // ,
      // freelancer_copyright
    },
    methods: {
      updateCart(e) {
            this.cart.push(e);
            // alert(this.cart)
            // this.total = this.shoppingCartTotal;
      },
      upd(e){
        this.cart = e
      }
    },
    computed: {
        sortedCart() {
            // Return a copy of the sorted array
            // console.log(this.cart)
            return this.cart.filter(function(p){return p.qnt})
        },
        total(){
          var t = 0
          this.cart.forEach(function(a){
            t += parseInt(a.qnt) * parseFloat(a.price)
          })
          console.log(t);
          
          return t
          // return this.cart.filter(function(p){return p.qnt})
        }
    }
  }
</script>
